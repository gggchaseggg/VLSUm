import ex1 from './lab1-1'
import ex2 from './lab1-2'
import ex3 from './lab1-3'
import zad1 from './zad1'
import zad2 from './zad2'

window.onload = function () {
  ex1()
  ex2()
  ex3()
  zad1()
  zad2()
}