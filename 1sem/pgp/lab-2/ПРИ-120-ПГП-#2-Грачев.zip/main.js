import { webGLStart } from "./ex6";
import { webGLStart1 } from "./zad1";

window.onload = function () {
  webGLStart();
  webGLStart1();
};
